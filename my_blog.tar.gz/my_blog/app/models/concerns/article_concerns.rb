module ArticleConcerns
  $ARTICLE_DIR = "#{Dir.pwd}/articles"

end
