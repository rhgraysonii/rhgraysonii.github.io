require 'concerns/article_concerns'
require 'pry'

class Article < ActiveRecord::Base
  $ARTICLE_DIR = "#{Dir.pwd}/articles/"
  attr_reader :article_text
  attr_writer :article_text

  def self.db_to_github
    Article.all.map { |article|
      File.open("#{$ARTICLE_DIR}#{article.id}.md", "wb") { |file|
        file.write article.article_text
      }
    }
  end

  def test
    binding.pry
  end
end
